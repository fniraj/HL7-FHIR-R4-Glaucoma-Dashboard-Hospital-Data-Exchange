"""Synthetic FHIR transfer demonstration: HAPI FHIR R4 -> local Hospital B HTTP receiver."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import requests
import streamlit as st

SOURCE = 'https://hapi.fhir.org/baseR4'
DEST = 'http://127.0.0.1:8765'
DATA = Path(__file__).resolve().parent / 'hospital_b_records.json'
IDS = {
    'Patient': ['789264'],
    'Observation': ['789321', '789322'],
    'Condition': ['789323'],
    'MedicationRequest': ['789324'],
    'Encounter': ['789325'],
}

class Receiver(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def respond(self, status, obj):
        raw = json.dumps(obj).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/fhir+json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        if self.path != '/fhir/Bundle':
            return self.respond(404, {'error': 'Not found'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length <= 0 or length > 2_000_000:
                return self.respond(413, {'error': 'Invalid size'})
            bundle = json.loads(self.rfile.read(length))
            if bundle.get('resourceType') != 'Bundle' or bundle.get('type') != 'transaction':
                return self.respond(400, {'error': 'Expected FHIR transaction Bundle'})
            entries = bundle.get('entry', [])
            if not entries:
                return self.respond(400, {'error': 'Empty Bundle'})
            records = {}
            for entry in entries:
                resource = entry['resource']
                resource_type, rid = resource['resourceType'], str(resource['id'])
                if resource_type not in IDS or not rid.isdigit():
                    return self.respond(400, {'error': 'Unexpected resource'})
                records[f'{resource_type}/{rid}'] = resource
            # This local demo receiver persists FHIR-shaped resources; it is not a full FHIR server.
            DATA.write_text(json.dumps(records, indent=2), encoding='utf-8')
            self.respond(200, {'resourceType': 'Bundle', 'type': 'transaction-response',
                               'entry': [{'response': {'status': '200 OK', 'location': key}}
                                         for key in records]})
        except (ValueError, KeyError, TypeError) as exc:
            self.respond(400, {'error': str(exc)})
        except OSError as exc:
            self.respond(500, {'error': str(exc)})

    def do_GET(self):
        if not self.path.startswith('/fhir/'):
            return self.respond(404, {'error': 'Not found'})
        key = self.path[len('/fhir/'):]
        try:
            records = json.loads(DATA.read_text(encoding='utf-8')) if DATA.exists() else {}
            resource = records.get(key)
            self.respond(200 if resource else 404, resource or {'error': 'Resource not found'})
        except (ValueError, OSError) as exc:
            self.respond(500, {'error': str(exc)})

@st.cache_resource
def start_receiver():
    try:
        server = ThreadingHTTPServer(('127.0.0.1', 8765), Receiver)
    except OSError as exc:
        return f'Could not start Hospital B on port 8765: {exc}'
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return None

st.set_page_config(page_title='FHIR Hospital Transfer', page_icon='🏥', layout='wide')
st.title('FHIR Hospital A → Hospital B Transfer')
st.caption('Synthetic data | Hospital A: HAPI FHIR R4 | Hospital B: separate local HTTP receiver')
error = start_receiver()
if error:
    st.error(error)
    st.stop()

st.write('**Patient:** Amit Kumar | **FHIR Patient ID:** 789264')
st.write('**Transfer:** Patient, 2 IOP observations, glaucoma diagnosis, medication request, encounter (6 resources).')

if st.button('Transfer records from Hospital A to Hospital B', type='primary'):
    try:
        resources = []
        for resource_type, ids in IDS.items():
            for rid in ids:
                r = requests.get(f'{SOURCE}/{resource_type}/{rid}',
                                 headers={'Accept': 'application/fhir+json'}, timeout=25)
                r.raise_for_status()
                resource = r.json()
                if resource.get('resourceType') != resource_type or str(resource.get('id')) != rid:
                    raise ValueError(f'Unexpected response for {resource_type}/{rid}')
                resources.append(resource)
        bundle = {'resourceType': 'Bundle', 'type': 'transaction',
                  'entry': [{'resource': r, 'request': {'method': 'PUT',
                             'url': f"{r['resourceType']}/{r['id']}"}} for r in resources]}
        posted = requests.post(f'{DEST}/fhir/Bundle', json=bundle, timeout=15)
        posted.raise_for_status()
        st.success(f'Hospital B received {len(resources)} resources via HTTP POST.')
        st.code(f'POST {DEST}/fhir/Bundle → HTTP {posted.status_code}')
    except (requests.RequestException, ValueError) as exc:
        st.error(f'Transfer failed: {exc}. Public HAPI test data may have been reset.')

st.subheader('Verify Hospital B received the records')
if st.button('Verify transfer'):
    received = []
    missing = []
    for resource_type, ids in IDS.items():
        for rid in ids:
            try:
                response = requests.get(f'{DEST}/fhir/{resource_type}/{rid}', timeout=5)
                (received if response.status_code == 200 else missing).append(f'{resource_type}/{rid}')
            except requests.RequestException:
                missing.append(f'{resource_type}/{rid}')
    if missing:
        st.warning(f'{len(received)} received; {len(missing)} missing. Click Transfer first.')
        st.write('Missing:', ', '.join(missing))
    else:
        st.success('Verified: all 6 FHIR resources are stored at Hospital B.')
        st.write('Hospital B has its own local copy in `hospital_b_records.json`.')
        patient = requests.get(f'{DEST}/fhir/Patient/789264', timeout=5).json()
        st.json(patient)

st.info('Training demonstration only: Hospital B is a simplified local HTTP receiver, not a production FHIR server. It does not implement authentication, patient matching, consent, or full FHIR validation. Do not use real patient data.')
