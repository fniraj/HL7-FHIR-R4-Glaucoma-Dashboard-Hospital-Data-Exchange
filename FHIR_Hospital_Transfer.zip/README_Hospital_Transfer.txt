FHIR Hospital A to Hospital B Transfer (synthetic training demonstration)

1. Save hospital_transfer.py in Downloads (or extract ZIP there).
2. In VS Code terminal:
   cd C:\Users\niraj\Downloads
   python -m streamlit run hospital_transfer.py
3. In browser, click 'Transfer records from Hospital A to Hospital B'.
4. Click 'Verify transfer'.

Hospital A: public HAPI FHIR R4 test server.
Hospital B: local HTTP receiver at http://127.0.0.1:8765, persisting to hospital_b_records.json.
Hospital B is a simplified receiver, not a complete FHIR-compliant server.
If HAPI test records expire, the transfer will fail until the sample records are recreated.
No real patient data should be used.
